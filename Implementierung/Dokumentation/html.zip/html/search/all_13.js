var searchData=
[
  ['week',['Week',['../namespacemy_m_d_1_1_model_interface_1_1_data_model_interface.html#ad48afcd64f57a7b985ed525a6c054782ad2ce009594dcc60befa6a4e6cbeb71fc',1,'myMD::ModelInterface::DataModelInterface']]]
];
