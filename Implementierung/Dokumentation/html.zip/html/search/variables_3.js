var searchData=
[
  ['modelfacade',['ModelFacade',['../classmy_m_d_1_1_view_model_1_1_overall_view_model_1_1_overall_view_model.html#ab1b0e7b2ed9ae07614caa1e45b942e3f',1,'myMD::ViewModel::OverallViewModel::OverallViewModel']]]
];
