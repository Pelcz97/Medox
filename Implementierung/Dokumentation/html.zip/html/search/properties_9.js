var searchData=
[
  ['lastdate',['LastDate',['../interfacemy_m_d_1_1_model_interface_1_1_data_model_interface_1_1_i_doctors_letter_group.html#aae3692100f685fc02336c79a83e94d18',1,'myMD::ModelInterface::DataModelInterface::IDoctorsLetterGroup']]],
  ['lastname',['LastName',['../classmy_m_d_1_1_model_1_1_data_model_1_1_profile.html#a7871b0de751bccf0e6cd9a89c4d9605c',1,'myMD.Model.DataModel.Profile.LastName()'],['../interfacemy_m_d_1_1_model_interface_1_1_data_model_interface_1_1_i_profile.html#a9647258e141ac7cc6a628eb901886d78',1,'myMD.ModelInterface.DataModelInterface.IProfile.LastName()'],['../classmy_m_d_1_1_view_model_1_1_profile_tab_view_model_1_1_profile_item_view_model.html#abf7ee39f67915e326cbaa633368b9846',1,'myMD.ViewModel.ProfileTabViewModel.ProfileItemViewModel.LastName()']]],
  ['letterid',['LetterId',['../classmy_m_d_1_1_model_1_1_data_model_1_1_medication.html#ad912f439eb0ba72cff231ecfc0adbcba',1,'myMD::Model::DataModel::Medication']]],
  ['localname',['LocalName',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_scan_result_view_model.html#ad98e9265244511282e9a84855021ab3e',1,'myMD::ViewModel::SendDataTabViewModel::ScanResultViewModel']]]
];
