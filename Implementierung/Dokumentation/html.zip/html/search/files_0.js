var searchData=
[
  ['app_2examl',['App.xaml',['../_app_8xaml.html',1,'']]],
  ['app_2examl_2ecs',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]]
];
