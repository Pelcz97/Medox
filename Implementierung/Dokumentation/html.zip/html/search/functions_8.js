var searchData=
[
  ['init',['Init',['../classmy_m_d_1_1_model_1_1_parser_model_1_1_file_to_database_parser.html#afa4317cee37448666f91ad019c4d118e',1,'myMD.Model.ParserModel.FileToDatabaseParser.Init()'],['../classmy_m_d_1_1_model_1_1_parser_model_1_1_hl7_to_database_parser.html#a5c2d04fd614ecab8c9bc7f5ae7636a00',1,'myMD.Model.ParserModel.Hl7ToDatabaseParser.Init()']]],
  ['insert',['Insert',['../classmy_m_d_1_1_model_1_1_database_model_1_1_entity_database.html#a498caa3b7e7a7745f7066620ac9a14ae',1,'myMD.Model.DatabaseModel.EntityDatabase.Insert()'],['../interfacemy_m_d_1_1_model_1_1_database_model_1_1_i_entity_database.html#aa9b390a965a4ebc813c0beefbbd87d26',1,'myMD.Model.DatabaseModel.IEntityDatabase.Insert()']]]
];
