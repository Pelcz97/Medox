var searchData=
[
  ['profile',['Profile',['../classmy_m_d_1_1_model_1_1_data_model_1_1_entity.html#a3df9a6eed5a26b09bbf075615db46b9c',1,'myMD.Model.DataModel.Entity.Profile()'],['../classmy_m_d_1_1_view_model_1_1_profile_tab_view_model_1_1_profile_item_view_model.html#a91367f8be2f7fda904e1292cd5049c35',1,'myMD.ViewModel.ProfileTabViewModel.ProfileItemViewModel.Profile()']]],
  ['profileid',['ProfileID',['../classmy_m_d_1_1_model_1_1_data_model_1_1_entity.html#a54eef4f2993b1ed6467ee8a7d4b1a4b7',1,'myMD::Model::DataModel::Entity']]]
];
