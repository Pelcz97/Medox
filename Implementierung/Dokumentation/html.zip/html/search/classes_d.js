var searchData=
[
  ['transmittingdatapage',['TransmittingDataPage',['../classmy_m_d_1_1_view_1_1_send_data_tab_pages_1_1_transmitting_data_page.html',1,'myMD::View::SendDataTabPages']]],
  ['transmittingdataviewmodel',['TransmittingDataViewModel',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_transmitting_data_view_model.html',1,'myMD::ViewModel::SendDataTabViewModel']]]
];
