var searchData=
[
  ['cancelpossible',['CancelPossible',['../classmy_m_d_1_1_view_model_1_1_medication_tab_view_model_1_1_medicine_view_model.html#ae2bbbd81c983dbab025a3ed6a858c535',1,'myMD::ViewModel::MedicationTabViewModel::MedicineViewModel']]]
];
