var searchData=
[
  ['name',['Name',['../classmy_m_d_1_1_model_1_1_data_model_1_1_entity.html#a752f68aa01561c06c77bc2d3324a46e7',1,'myMD.Model.DataModel.Entity.Name()'],['../interfacemy_m_d_1_1_model_interface_1_1_data_model_interface_1_1_i_entity.html#a8160d8399f68f5db325a517c3114f7ae',1,'myMD.ModelInterface.DataModelInterface.IEntity.Name()'],['../classmy_m_d_1_1_view_model_1_1_profile_tab_view_model_1_1_profile_item_view_model.html#aa16bc16413aef57a6b63caedf7b5632a',1,'myMD.ViewModel.ProfileTabViewModel.ProfileItemViewModel.Name()']]],
  ['namesort',['NameSort',['../classmy_m_d_1_1_view_model_1_1_medication_tab_view_model_1_1_medicine_view_model.html#a93c6d3fe1297957deadbd1dc0d29475a',1,'myMD::ViewModel::MedicationTabViewModel::MedicineViewModel']]]
];
