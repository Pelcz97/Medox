var searchData=
[
  ['savingpossible',['SavingPossible',['../classmy_m_d_1_1_view_model_1_1_medication_tab_view_model_1_1_medicine_view_model.html#a9ada30bb9027a311c3934cef06431310',1,'myMD::ViewModel::MedicationTabViewModel::MedicineViewModel']]],
  ['scan',['scan',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_select_device_view_model.html#a863852899d8408a5decf7f9e724163f9',1,'myMD::ViewModel::SendDataTabViewModel::SelectDeviceViewModel']]],
  ['scanfordevices_5fclicked',['ScanForDevices_Clicked',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_select_device_view_model.html#a4cc73a2d15f2489105da96da595750b0',1,'myMD::ViewModel::SendDataTabViewModel::SelectDeviceViewModel']]],
  ['sensitivity',['Sensitivity',['../classmy_m_d_1_1_model_1_1_data_model_1_1_data.html#ac34e47038aebd438d8e85639aa1b3fbe',1,'myMD.Model.DataModel.Data.Sensitivity()'],['../interfacemy_m_d_1_1_model_interface_1_1_data_model_interface_1_1_i_data.html#a8ff35b1b7aeffdb14c900e6c807b1e4e',1,'myMD.ModelInterface.DataModelInterface.IData.Sensitivity()']]]
];
