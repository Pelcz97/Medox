var searchData=
[
  ['bloodtype',['BloodType',['../namespacemy_m_d_1_1_model_interface_1_1_data_model_interface.html#a5da1f31200b9d5cbc5d0704b8da3d17c',1,'myMD::ModelInterface::DataModelInterface']]]
];
