var searchData=
[
  ['scanresultviewmodel_2ecs',['ScanResultViewModel.cs',['../_scan_result_view_model_8cs.html',1,'']]],
  ['selectdevicepage_2examl',['SelectDevicePage.xaml',['../_select_device_page_8xaml.html',1,'']]],
  ['selectdevicepage_2examl_2ecs',['SelectDevicePage.xaml.cs',['../_select_device_page_8xaml_8cs.html',1,'']]],
  ['selectdeviceviewmodel_2ecs',['SelectDeviceViewModel.cs',['../_select_device_view_model_8cs.html',1,'']]],
  ['selectdoctorsletterspage_2examl',['SelectDoctorsLettersPage.xaml',['../_select_doctors_letters_page_8xaml.html',1,'']]],
  ['selectdoctorsletterspage_2examl_2ecs',['SelectDoctorsLettersPage.xaml.cs',['../_select_doctors_letters_page_8xaml_8cs.html',1,'']]],
  ['selectdoctorslettersviewmodel_2ecs',['SelectDoctorsLettersViewModel.cs',['../_select_doctors_letters_view_model_8cs.html',1,'']]],
  ['senddatapage_2examl',['SendDataPage.xaml',['../_send_data_page_8xaml.html',1,'']]],
  ['senddatapage_2examl_2ecs',['SendDataPage.xaml.cs',['../_send_data_page_8xaml_8cs.html',1,'']]],
  ['senddataviewmodel_2ecs',['SendDataViewModel.cs',['../_send_data_view_model_8cs.html',1,'']]],
  ['sensitivity_2ecs',['Sensitivity.cs',['../_sensitivity_8cs.html',1,'']]],
  ['stringextensions_2ecs',['StringExtensions.cs',['../_string_extensions_8cs.html',1,'']]]
];
