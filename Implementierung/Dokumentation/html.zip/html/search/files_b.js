var searchData=
[
  ['parserfacade_2ecs',['ParserFacade.cs',['../_parser_facade_8cs.html',1,'']]],
  ['profile_2ecs',['Profile.cs',['../_profile_8cs.html',1,'']]],
  ['profileeditpage_2examl',['ProfileEditPage.xaml',['../_profile_edit_page_8xaml.html',1,'']]],
  ['profileeditpage_2examl_2ecs',['ProfileEditPage.xaml.cs',['../_profile_edit_page_8xaml_8cs.html',1,'']]],
  ['profileeditviewmodel_2ecs',['ProfileEditViewModel.cs',['../_profile_edit_view_model_8cs.html',1,'']]],
  ['profileitemviewmodel_2ecs',['ProfileItemViewModel.cs',['../_profile_item_view_model_8cs.html',1,'']]],
  ['profilepage_2examl',['ProfilePage.xaml',['../_profile_page_8xaml.html',1,'']]],
  ['profilepage_2examl_2ecs',['ProfilePage.xaml.cs',['../_profile_page_8xaml_8cs.html',1,'']]],
  ['profileviewmodel_2ecs',['ProfileViewModel.cs',['../_profile_view_model_8cs.html',1,'']]]
];
