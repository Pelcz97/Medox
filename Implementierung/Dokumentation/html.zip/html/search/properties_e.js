var searchData=
[
  ['uuid',['Uuid',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_scan_result_view_model.html#a85f6973e1fc06fbbf200988d583fdb01',1,'myMD::ViewModel::SendDataTabViewModel::ScanResultViewModel']]]
];
