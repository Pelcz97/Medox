var searchData=
[
  ['propertychanged',['PropertyChanged',['../classmy_m_d_1_1_view_model_1_1_overall_view_model_1_1_overall_view_model.html#a1918d3d8d384486e278426327b16256f',1,'myMD::ViewModel::OverallViewModel::OverallViewModel']]]
];
