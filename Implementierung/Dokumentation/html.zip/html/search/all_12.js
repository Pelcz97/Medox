var searchData=
[
  ['update',['Update',['../classmy_m_d_1_1_model_1_1_database_model_1_1_entity_database.html#a193a4912949f792f9907fad34802ff19',1,'myMD.Model.DatabaseModel.EntityDatabase.Update()'],['../interfacemy_m_d_1_1_model_1_1_database_model_1_1_i_entity_database.html#a61821f96fe74626966cdb12ca9691de1',1,'myMD.Model.DatabaseModel.IEntityDatabase.Update()'],['../classmy_m_d_1_1_model_1_1_model_facade_1_1_model_facade.html#a25149455d25ce5c187c1f8f50c9735ba',1,'myMD.Model.ModelFacade.ModelFacade.Update()'],['../interfacemy_m_d_1_1_model_interface_1_1_model_facade_interface_1_1_i_model_facade.html#ad3fe364e44e55623a6e4a3a8920da8dd',1,'myMD.ModelInterface.ModelFacadeInterface.IModelFacade.Update()']]],
  ['uuid',['Uuid',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_scan_result_view_model.html#a85f6973e1fc06fbbf200988d583fdb01',1,'myMD::ViewModel::SendDataTabViewModel::ScanResultViewModel']]]
];
