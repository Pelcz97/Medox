var searchData=
[
  ['customcontentpage_2examl',['CustomContentPage.xaml',['../_custom_content_page_8xaml.html',1,'']]],
  ['customcontentpage_2examl_2ecs',['CustomContentPage.xaml.cs',['../_custom_content_page_8xaml_8cs.html',1,'']]]
];
