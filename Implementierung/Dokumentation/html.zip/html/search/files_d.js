var searchData=
[
  ['transmittingdatapage_2examl',['TransmittingDataPage.xaml',['../_transmitting_data_page_8xaml.html',1,'']]],
  ['transmittingdatapage_2examl_2ecs',['TransmittingDataPage.xaml.cs',['../_transmitting_data_page_8xaml_8cs.html',1,'']]],
  ['transmittingdataviewmodel_2ecs',['TransmittingDataViewModel.cs',['../_transmitting_data_view_model_8cs.html',1,'']]]
];
