var searchData=
[
  ['groups',['Groups',['../classmy_m_d_1_1_model_1_1_data_model_1_1_doctors_letter.html#a83230d33ed1e67dab06eb9c63f03699f',1,'myMD.Model.DataModel.DoctorsLetter.Groups()'],['../interfacemy_m_d_1_1_model_interface_1_1_data_model_interface_1_1_i_doctors_letter.html#a1b061be65bc92eb5941fca68f0ad3e7e',1,'myMD.ModelInterface.DataModelInterface.IDoctorsLetter.Groups()']]]
];
