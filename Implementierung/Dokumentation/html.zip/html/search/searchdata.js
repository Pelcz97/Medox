var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuwy",
  1: "abcdefhilmopst",
  2: "m",
  3: "abcdefhilmopst",
  4: "abcdefghimoprstu",
  5: "bdlm",
  6: "bfis",
  7: "abdehlmnowy",
  8: "abcdefgiklmnpsu",
  9: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Klassen",
  2: "Namensbereiche",
  3: "Dateien",
  4: "Funktionen",
  5: "Variablen",
  6: "Aufzählungen",
  7: "Aufzählungswerte",
  8: "Propertys",
  9: "Ereignisse"
};

