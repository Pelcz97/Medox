var searchData=
[
  ['buildserver',['BuildServer',['../classmy_m_d_1_1_view_model_1_1_send_data_tab_view_model_1_1_transmitting_data_view_model.html#acd2a4a33751f02b1f16bb8c666b98f34',1,'myMD::ViewModel::SendDataTabViewModel::TransmittingDataViewModel']]]
];
